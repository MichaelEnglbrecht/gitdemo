sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function(Controller,MessageToast,MessageBox) {
	"use strict";

	return Controller.extend("sap.training.controller.Main", {
		onUserChange: function(oEvent) {
			var oTableItem = oEvent.getParameter("listItem");
			var oForm = this.getView().byId("UserForm");
			var sPath = oTableItem.getBindingContext().getPath();
			this._oBindingContext = oTableItem.getBindingContext();
			this._selectedUser = sPath;
			oForm.bindElement(sPath);
		},
		
		onSaveData : function(oEvent) {
			var mParameters = {
					  success: function(oError){
						  MessageToast.show("Success", {duration: 5000});
						  },
						  error: function(oError){
							  MessageBox.error("Following error occured" + oError, {
								    title: "Error"								    
								    });
						  }
			}
			
			var oDataModel = this.getOwnerComponent().getModel();
			oDataModel.submitChanges(mParameters);
		},
		
		onDeleteUser : function(oEvent) {
			if(this._selectedUser) {
				var mParameters = {
						  success: function(oError){
							  MessageToast.show("Success", {duration: 5000});
							  },
							  error: function(oError){
								  MessageBox.error("Following error occured" + oError, {
									    title: "Error"								    
									    });
							  }
				}
				
				var oDataModel = this.getOwnerComponent().getModel();
				oDataModel.remove(this._oBindingContext.getPath());
			}
		},
		
		onNewUser : function(oEvent) {
			var mParameters = {
					  success: function(oError){
						  MessageToast.show("Success", {duration: 5000});
						  },
						  error: function(oError){
							  MessageBox.error("Following error occured" + oError, {
								    title: "Error"								    
								    });
						  }
			}
			
			var oDataModel = this.getOwnerComponent().getModel();
			var oBindingContext = oDataModel.createEntry("/ZDTA_USER_ENTSet");
			var oForm = this.getView().byId("UserForm");
			
			oForm.bindElement(oBindingContext.getPath());
		},
		
		formatString2Int : function(oValue) {
			if(oValue) {
				return parseInt(oValue);
			}
			return oValue;
		},
		
		formatString2Bool : function(oValue) {			
			if(oValue == "false")
				return false;
			return true;
		}
	});
});